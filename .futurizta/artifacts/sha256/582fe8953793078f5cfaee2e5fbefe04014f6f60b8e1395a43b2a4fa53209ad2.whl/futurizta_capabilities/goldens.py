from __future__ import annotations

import hashlib
from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class GoldenFixture(StrictModel):
    id: str = Field(min_length=1)
    domain: str = Field(min_length=1)
    role: str = Field(pattern=r"^(positive|negative|review|contract|reference)$")
    path: str = Field(min_length=1)
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    expectation: str = Field(min_length=1)
    caveat: str | None = None
    subjectId: str | None = None
    style: str | None = None
    colorway: str | None = None
    metadata: dict[str, object] = Field(default_factory=dict)


class GoldenSet(StrictModel):
    apiVersion: str = Field(pattern=r"^futurizta\.goldens/v1$")
    sourceRepository: str
    fixtures: list[GoldenFixture] = Field(min_length=1)


def load_golden_set(path: str | Path) -> GoldenSet:
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return GoldenSet.model_validate(raw)


def verify_golden_set(path: str | Path) -> list[str]:
    golden_path = Path(path).resolve()
    golden_set = load_golden_set(golden_path)
    repository = Path(golden_set.sourceRepository).expanduser()
    if not repository.is_absolute():
        repository = golden_path.parent / repository
    repository = repository.resolve()
    errors: list[str] = []
    seen: set[str] = set()

    for fixture in golden_set.fixtures:
        if fixture.id in seen:
            errors.append(f"duplicate fixture id: {fixture.id}")
            continue
        seen.add(fixture.id)

        target = (repository / fixture.path).resolve()
        if not target.is_relative_to(repository):
            errors.append(f"fixture path escapes repository: {fixture.path}")
            continue
        if not target.is_file():
            errors.append(f"missing fixture: {fixture.path}")
            continue
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        if digest != fixture.sha256:
            errors.append(f"fixture checksum changed: {fixture.path}")

    return errors
