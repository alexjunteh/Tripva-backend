from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from .goldens import verify_golden_set
from .inventory import scan_repository, write_inventory
from .install import install_release, package_release, plan_json
from .manifest import validate_manifest


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="capability")
    commands = parser.add_subparsers(dest="command", required=True)

    validate = commands.add_parser("validate", help="validate a capability manifest")
    validate.add_argument("path")

    inventory = commands.add_parser("inventory", help="scan source coupling without reading secret values")
    inventory.add_argument("repository")
    inventory.add_argument("--include", action="append", default=[])
    inventory.add_argument("--output")

    goldens = commands.add_parser("verify-goldens", help="verify golden fixture identity")
    goldens.add_argument("path")

    package = commands.add_parser("package", help="build a release from the committed source tree")
    package.add_argument("manifest")
    package.add_argument("--output", required=True)

    install = commands.add_parser("install", help="plan or apply a committed disabled release")
    install.add_argument("release")
    install.add_argument("--target", required=True)
    install.add_argument("--binding", required=True)
    install.add_argument("--apply", action="store_true")
    install.add_argument("--upgrade", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "validate":
        manifest, errors = validate_manifest(args.path)
        if errors:
            for error in errors:
                print(error)
            return 1
        assert manifest is not None
        print(f"valid: {manifest.name}@{manifest.version} ({manifest.kind})")
        return 0

    if args.command == "inventory":
        result = scan_repository(args.repository, args.include)
        if args.output:
            write_inventory(result, args.output)
            print(f"wrote {args.output}: {result.summary['fileCount']} files")
        else:
            print(json.dumps(result.to_dict(), indent=2))
        return 0

    if args.command == "verify-goldens":
        errors = verify_golden_set(args.path)
        if errors:
            for error in errors:
                print(f"error: {error}", file=sys.stderr)
            return 1
        print(f"valid: {args.path}")
        return 0

    if args.command == "package":
        try:
            release = package_release(args.manifest, args.output)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        print(release)
        return 0

    if args.command == "install":
        try:
            plan = install_release(
                args.release,
                args.target,
                args.binding,
                apply=args.apply,
                upgrade=args.upgrade,
            )
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        print(plan_json(plan))
        return 0

    return 2
