from __future__ import annotations

import base64
import csv
import fcntl
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import tomllib
import zipfile
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version as installed_version
from pathlib import Path, PurePosixPath
from typing import Literal

import yaml
from packaging.requirements import InvalidRequirement, Requirement
from pydantic import Field, model_validator

from .manifest import CapabilityManifest, StrictModel, load_manifest


class BindingPolicy(StrictModel):
    network: Literal["denied"] = "denied"
    providerSpend: Literal["denied"] = "denied"
    productionWrites: Literal["denied"] = "denied"
    externalActions: Literal["denied"] = "denied"


class BindingVerification(StrictModel):
    commands: list[str] = Field(min_length=1)


class ProjectBinding(StrictModel):
    apiVersion: Literal["futurizta.bindings/v1"]
    capability: str
    enabled: Literal[False]
    mode: Literal["shadow"]
    adapters: dict[str, str]
    runtimeDependencies: list[str] = Field(default_factory=list)
    configuration: dict[str, object] = Field(default_factory=dict)
    policy: BindingPolicy = Field(default_factory=BindingPolicy)
    verification: BindingVerification

    @model_validator(mode="after")
    def adapter_values_are_entrypoints(self) -> "ProjectBinding":
        for name, entrypoint in self.adapters.items():
            if not name or entrypoint.count(":") != 1:
                raise ValueError("adapter bindings must use name: module:object entrypoints")
            module, symbol = entrypoint.split(":", 1)
            if (
                not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)*", module)
                or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", symbol)
            ):
                raise ValueError(f"invalid adapter entrypoint: {entrypoint}")
        for value in self.runtimeDependencies:
            try:
                Requirement(value)
            except InvalidRequirement as exc:
                raise ValueError(f"invalid runtime dependency: {value}") from exc
        return self


class ReleaseCapability(StrictModel):
    name: str
    version: str
    kind: str


class ReleaseManifest(StrictModel):
    path: str
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")


class ReleaseArtifact(StrictModel):
    path: str
    distribution: Literal["futurizta-capabilities"]
    filename: str
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")


class CapabilityRelease(StrictModel):
    apiVersion: Literal["futurizta.capabilities.release/v1"]
    repository: str
    releaseCommit: str = Field(pattern=r"^[a-f0-9]{40}$")
    sourceTree: str = Field(pattern=r"^[a-f0-9]{40,64}$")
    capability: ReleaseCapability
    manifest: ReleaseManifest
    artifact: ReleaseArtifact


@dataclass(frozen=True)
class LoadedRelease:
    descriptor: CapabilityRelease
    repository: Path
    manifest: CapabilityManifest
    artifact: Path


@dataclass(frozen=True)
class InstallPlan:
    capability: str
    version: str
    release_commit: str
    source_tree: str
    artifact_sha256: str
    binding_sha256: str
    operations: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "capability": self.capability,
            "version": self.version,
            "releaseCommit": self.release_commit,
            "sourceTree": self.source_tree,
            "artifactSha256": self.artifact_sha256,
            "bindingSha256": self.binding_sha256,
            "operations": list(self.operations),
        }


def _yaml_bytes(value: object) -> bytes:
    return yaml.safe_dump(value, sort_keys=True, allow_unicode=False).encode()


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _git(repository: Path, *args: str) -> bytes:
    result = subprocess.run(
        ["git", "-C", str(repository), *args],
        check=True,
        capture_output=True,
        timeout=30,
    )
    return result.stdout


def _git_text(repository: Path, *args: str) -> str:
    return _git(repository, *args).decode().strip()


def _repository_for_manifest(manifest_file: Path, manifest: CapabilityManifest) -> Path:
    repository = Path(manifest.source.repository).expanduser()
    if not repository.is_absolute():
        repository = manifest_file.parent / repository
    repository = repository.resolve()
    if not (repository / ".git").exists():
        raise ValueError("capability source must be a Git repository")
    return repository


def _relative_git_path(repository: Path, path: Path) -> str:
    resolved = path.resolve()
    if not resolved.is_relative_to(repository):
        raise ValueError("release path is outside its repository")
    return resolved.relative_to(repository).as_posix()


def _distribution_metadata(archive: zipfile.ZipFile) -> tuple[str, str, tuple[str, ...]]:
    metadata_names = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
    if len(metadata_names) != 1:
        raise ValueError("wheel must contain exactly one distribution METADATA file")
    fields: dict[str, str] = {}
    requirements: list[str] = []
    for line in archive.read(metadata_names[0]).decode("utf-8").splitlines():
        if ": " in line:
            key, value = line.split(": ", 1)
            fields.setdefault(key, value)
            if key == "Requires-Dist":
                requirements.append(value)
    return (
        fields.get("Name", "").lower().replace("_", "-"),
        fields.get("Version", ""),
        tuple(requirements),
    )


def _verify_wheel_record(archive: zipfile.ZipFile) -> None:
    records = [name for name in archive.namelist() if name.endswith(".dist-info/RECORD")]
    if len(records) != 1:
        raise ValueError("wheel must contain exactly one RECORD")
    rows = list(csv.reader(io.StringIO(archive.read(records[0]).decode("utf-8"))))
    recorded = {row[0] for row in rows}
    if recorded != set(archive.namelist()):
        raise ValueError("wheel RECORD does not cover every archive member")
    for path, digest, size in rows:
        if path == records[0]:
            continue
        if not digest.startswith("sha256=") or not size:
            raise ValueError(f"wheel RECORD entry is not hash-pinned: {path}")
        content = archive.read(path)
        encoded = base64.urlsafe_b64encode(hashlib.sha256(content).digest()).rstrip(b"=").decode()
        if digest != f"sha256={encoded}" or int(size) != len(content):
            raise ValueError(f"wheel RECORD mismatch: {path}")


def _validate_wheel(wheel: Path, manifest: CapabilityManifest, manifest_bytes: bytes) -> None:
    if not wheel.is_file() or wheel.suffix != ".whl":
        raise ValueError("release artifact must be a wheel")
    with zipfile.ZipFile(wheel) as archive:
        name, version, _ = _distribution_metadata(archive)
        if name != "futurizta-capabilities" or version != manifest.version:
            raise ValueError(
                f"wheel identity mismatch: expected futurizta-capabilities=={manifest.version}, "
                f"got {name}=={version}"
            )
        embedded = [
            name
            for name in archive.namelist()
            if name.endswith(
                f"share/futurizta-capabilities/capabilities/{manifest.name}/capability.yaml"
            )
        ]
        if len(embedded) != 1 or archive.read(embedded[0]) != manifest_bytes:
            raise ValueError("wheel embedded manifest does not match release manifest")
        _verify_wheel_record(archive)


def _resolved_dependencies(wheel: Path, binding: ProjectBinding) -> dict[str, str]:
    with zipfile.ZipFile(wheel) as archive:
        _, _, wheel_requirements = _distribution_metadata(archive)
    requirements = [Requirement(value) for value in wheel_requirements]
    requirements.extend(Requirement(value) for value in binding.runtimeDependencies)
    resolved: dict[str, str] = {}
    for requirement in requirements:
        if requirement.marker is not None and not requirement.marker.evaluate():
            continue
        try:
            actual = installed_version(requirement.name)
        except PackageNotFoundError as exc:
            raise ValueError(f"required runtime dependency is not installed: {requirement}") from exc
        if requirement.specifier and actual not in requirement.specifier:
            raise ValueError(
                f"runtime dependency is incompatible: {requirement.name}=={actual} "
                f"does not satisfy {requirement.specifier}"
            )
        normalized = requirement.name.lower().replace("_", "-")
        previous = resolved.get(normalized)
        if previous is not None and previous != actual:
            raise ValueError(f"runtime dependency resolution conflict: {requirement.name}")
        resolved[normalized] = actual
    return dict(sorted(resolved.items()))


def package_release(manifest_path: str | Path, output_path: str | Path) -> Path:
    manifest_file = Path(manifest_path).resolve()
    manifest = load_manifest(manifest_file)
    repository = _repository_for_manifest(manifest_file, manifest)
    if _git_text(repository, "status", "--porcelain"):
        raise ValueError("capability repository must be clean before packaging")
    commit = _git_text(repository, "rev-parse", "HEAD")
    tree = _git_text(repository, "rev-parse", "HEAD^{tree}")
    manifest_git_path = _relative_git_path(repository, manifest_file)
    manifest_bytes = _git(repository, "show", f"{commit}:{manifest_git_path}")
    if manifest_bytes != manifest_file.read_bytes():
        raise ValueError("manifest working copy differs from release commit")

    output = Path(output_path).resolve()
    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="capability-package-") as temp_dir:
        source = Path(temp_dir) / "source"
        source.mkdir()
        archive_bytes = _git(repository, "archive", "--format=tar", commit)
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:") as archive:
            archive.extractall(source, filter="data")
        wheel_dir = Path(temp_dir) / "wheel"
        wheel_dir.mkdir()
        environment = {**os.environ, "SOURCE_DATE_EPOCH": _git_text(repository, "show", "-s", "--format=%ct", commit)}
        subprocess.run(
            [sys.executable, "-m", "build", "--wheel", "--no-isolation", "--outdir", str(wheel_dir)],
            cwd=source,
            env=environment,
            check=True,
            capture_output=True,
            timeout=180,
        )
        wheels = list(wheel_dir.glob("*.whl"))
        if len(wheels) != 1:
            raise ValueError("package build did not produce exactly one wheel")
        wheel = wheels[0]
        _validate_wheel(wheel, manifest, manifest_bytes)
        artifact_sha = _sha256_file(wheel)
        artifact_dir = output / "artifacts"
        artifact_dir.mkdir(exist_ok=True)
        artifact = artifact_dir / f"{artifact_sha}.whl"
        shutil.copyfile(wheel, artifact)

    release = CapabilityRelease(
        apiVersion="futurizta.capabilities.release/v1",
        repository=os.path.relpath(repository, output),
        releaseCommit=commit,
        sourceTree=tree,
        capability=ReleaseCapability(name=manifest.name, version=manifest.version, kind=manifest.kind),
        manifest=ReleaseManifest(path=manifest_git_path, sha256=_sha256_bytes(manifest_bytes)),
        artifact=ReleaseArtifact(
            path=artifact.relative_to(output).as_posix(),
            distribution="futurizta-capabilities",
            filename=wheel.name,
            sha256=artifact_sha,
        ),
    )
    release_path = output / "release.yaml"
    _atomic_replace(release_path, _yaml_bytes(release.model_dump(mode="json")))
    return release_path


def load_release(path: str | Path) -> LoadedRelease:
    release_path = Path(path).resolve()
    descriptor = CapabilityRelease.model_validate(yaml.safe_load(release_path.read_text(encoding="utf-8")))
    repository = Path(descriptor.repository).expanduser()
    if not repository.is_absolute():
        repository = release_path.parent / repository
    repository = repository.resolve()
    release_git_path = _relative_git_path(repository, release_path)
    head_release = _git(repository, "show", f"HEAD:{release_git_path}")
    if head_release != release_path.read_bytes():
        raise ValueError("release descriptor must be committed and unchanged")
    tree = _git_text(repository, "rev-parse", f"{descriptor.releaseCommit}^{{tree}}")
    if tree != descriptor.sourceTree:
        raise ValueError("release source tree does not match release commit")
    manifest_bytes = _git(repository, "show", f"{descriptor.releaseCommit}:{descriptor.manifest.path}")
    if _sha256_bytes(manifest_bytes) != descriptor.manifest.sha256:
        raise ValueError("release manifest digest mismatch")
    manifest = CapabilityManifest.model_validate(yaml.safe_load(manifest_bytes))
    if (
        manifest.name != descriptor.capability.name
        or manifest.version != descriptor.capability.version
        or manifest.kind != descriptor.capability.kind
    ):
        raise ValueError("release capability identity does not match manifest")
    artifact = (release_path.parent / descriptor.artifact.path).resolve()
    if not artifact.is_relative_to(release_path.parent) or _sha256_file(artifact) != descriptor.artifact.sha256:
        raise ValueError("release artifact digest mismatch")
    artifact_git_path = _relative_git_path(repository, artifact)
    if _sha256_bytes(_git(repository, "show", f"HEAD:{artifact_git_path}")) != descriptor.artifact.sha256:
        raise ValueError("release artifact must be committed and unchanged")
    _validate_wheel(artifact, manifest, manifest_bytes)
    return LoadedRelease(descriptor, repository, manifest, artifact)


def load_binding(path: str | Path, manifest: CapabilityManifest, target: Path) -> ProjectBinding:
    binding = ProjectBinding.model_validate(yaml.safe_load(Path(path).read_text(encoding="utf-8")))
    if binding.capability != manifest.name:
        raise ValueError("binding capability does not match manifest")
    expected = set(manifest.compatibility.adapters)
    if set(binding.adapters) != expected:
        raise ValueError(
            f"adapter binding mismatch; missing={sorted(expected - set(binding.adapters))}, "
            f"extra={sorted(set(binding.adapters) - expected)}"
        )
    for entrypoint in binding.adapters.values():
        module, _ = entrypoint.split(":", 1)
        relative = Path(*module.split("."))
        candidates = (target / relative.with_suffix(".py"), target / relative / "__init__.py")
        if not any(
            candidate.resolve().is_relative_to(target) and candidate.resolve().is_file()
            for candidate in candidates
        ):
            raise ValueError(f"adapter module is missing or outside target: {module}")
    return binding


def _safe_root(target: Path) -> Path:
    target = target.resolve()
    if not (target / ".git").exists():
        raise ValueError("target must be a Git repository")
    root = target / ".futurizta"
    if root.exists() and (root.is_symlink() or not root.is_dir()):
        raise ValueError(".futurizta must be a real directory")
    root.mkdir(mode=0o700, exist_ok=True)
    if root.resolve().parent != target:
        raise ValueError(".futurizta escapes target repository")
    return root


def _safe_directory(root: Path, relative: Path) -> Path:
    current = root
    for part in relative.parts:
        current = current / part
        if current.exists() and (current.is_symlink() or not current.is_dir()):
            raise ValueError(f"install directory is unsafe: {current}")
        current.mkdir(mode=0o700, exist_ok=True)
    if not current.resolve().is_relative_to(root.resolve()):
        raise ValueError("install directory escapes .futurizta")
    return current


def _atomic_replace(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        directory_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        temp.unlink(missing_ok=True)


def _write_content_addressed(path: Path, content: bytes) -> None:
    if path.exists():
        if path.is_symlink() or path.read_bytes() != content:
            raise ValueError(f"content-addressed install file drifted: {path}")
        return
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags, 0o600)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def _safe_extract_wheel(wheel: Path, destination: Path) -> str:
    with tempfile.TemporaryDirectory(dir=destination.parent, prefix=".runtime-") as temp_dir:
        temp = Path(temp_dir)
        with zipfile.ZipFile(wheel) as archive:
            seen: set[str] = set()
            total_size = 0
            for info in archive.infolist():
                member = PurePosixPath(info.filename)
                normalized = member.as_posix().rstrip("/")
                if member.is_absolute() or ".." in member.parts or normalized in seen:
                    raise ValueError(f"unsafe wheel member: {info.filename}")
                seen.add(normalized)
                total_size += info.file_size
                if total_size > 100 * 1024 * 1024:
                    raise ValueError("wheel uncompressed size exceeds 100 MiB")
                top = member.parts[0] if member.parts else ""
                if not (
                    top in {"futurizta_capabilities", "futurizta_creative"}
                    or top.endswith(".dist-info")
                    or top.endswith(".data")
                ):
                    raise ValueError(f"unexpected wheel path: {info.filename}")
                if (info.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError(f"wheel contains symbolic link: {info.filename}")
                target = (temp / Path(*member.parts)).resolve()
                if not target.is_relative_to(temp.resolve()):
                    raise ValueError(f"wheel member escapes runtime: {info.filename}")
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as source, target.open("wb") as output:
                    shutil.copyfileobj(source, output)
                    output.flush()
                    os.fsync(output.fileno())
        digest = _tree_digest(temp)
        if destination.exists():
            if destination.is_symlink():
                raise ValueError("runtime path is a symbolic link")
            if _tree_digest(destination) == digest:
                return digest
            shutil.rmtree(destination)
        os.replace(temp, destination)
        return digest


def _tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix().encode()
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(bytes.fromhex(_sha256_file(path)))
    return digest.hexdigest()


def _current_python_matches(specification: str) -> bool:
    current = sys.version_info[:3]
    for clause in specification.split(","):
        match = re.fullmatch(r"\s*(>=|<=|>|<|==)\s*(\d+)\.(\d+)(?:\.(\d+))?\s*", clause)
        if not match:
            raise ValueError(f"unsupported Python compatibility specifier: {clause}")
        operator, major, minor, patch = match.groups()
        requested = (int(major), int(minor), int(patch or 0))
        comparisons = {
            ">=": current >= requested,
            "<=": current <= requested,
            ">": current > requested,
            "<": current < requested,
            "==": current == requested,
        }
        if not comparisons[operator]:
            return False
    return True


def install_release(
    release_path: str | Path,
    target_path: str | Path,
    binding_path: str | Path,
    *,
    apply: bool = False,
    upgrade: bool = False,
) -> InstallPlan:
    release = load_release(release_path)
    target = Path(target_path).resolve()
    binding = load_binding(binding_path, release.manifest, target)
    dependencies = _resolved_dependencies(release.artifact, binding)
    python_spec = release.manifest.compatibility.runtimes.get("python")
    if not python_spec or not _current_python_matches(python_spec):
        raise ValueError("current Python runtime is incompatible with capability")
    project_python = python_spec
    pyproject = target / "pyproject.toml"
    if pyproject.is_file():
        project_python = str(tomllib.loads(pyproject.read_text())["project"]["requires-python"])
        if not _current_python_matches(project_python):
            raise ValueError("current Python runtime is incompatible with target project")

    binding_bytes = _yaml_bytes(binding.model_dump(mode="json"))
    binding_sha = _sha256_bytes(binding_bytes)
    artifact_sha = release.descriptor.artifact.sha256
    artifact_relative = Path("artifacts/sha256") / f"{artifact_sha}.whl"
    runtime_relative = (
        Path("runtime")
        / release.manifest.name
        / release.manifest.version
        / artifact_sha[:16]
    )
    binding_relative = Path("bindings") / release.manifest.name / f"{binding_sha}.yaml"
    operations = (
        f"store .futurizta/{artifact_relative.as_posix()}",
        f"extract .futurizta/{runtime_relative.as_posix()}",
        f"write .futurizta/{binding_relative.as_posix()}",
        "commit .futurizta/capabilities.lock.yaml",
    )
    plan = InstallPlan(
        capability=release.manifest.name,
        version=release.manifest.version,
        release_commit=release.descriptor.releaseCommit,
        source_tree=release.descriptor.sourceTree,
        artifact_sha256=artifact_sha,
        binding_sha256=binding_sha,
        operations=operations,
    )
    if not apply:
        return plan

    root = _safe_root(target)
    lock_descriptor = os.open(
        root / ".install.lock",
        os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0),
        0o600,
    )
    with os.fdopen(lock_descriptor, "r+") as install_lock:
        fcntl.flock(install_lock.fileno(), fcntl.LOCK_EX)
        artifact_dir = _safe_directory(root, artifact_relative.parent)
        artifact_target = artifact_dir / artifact_relative.name
        _write_content_addressed(artifact_target, release.artifact.read_bytes())
        runtime_parent = _safe_directory(root, runtime_relative.parent)
        runtime_target = runtime_parent / runtime_relative.name
        runtime_digest = _safe_extract_wheel(artifact_target, runtime_target)
        binding_dir = _safe_directory(root, binding_relative.parent)
        binding_target = binding_dir / binding_relative.name
        _write_content_addressed(binding_target, binding_bytes)

        lock_path = root / "capabilities.lock.yaml"
        existing: dict[str, object] = {}
        if lock_path.exists():
            if lock_path.is_symlink():
                raise ValueError("capability lockfile cannot be a symbolic link")
            existing = yaml.safe_load(lock_path.read_text(encoding="utf-8"))
            if not isinstance(existing, dict) or existing.get("apiVersion") != "futurizta.lock/v1":
                raise ValueError("existing capability lockfile is invalid")
        capabilities = dict(existing.get("capabilities") or {})
        locked = {
            "version": release.manifest.version,
            "releaseCommit": release.descriptor.releaseCommit,
            "sourceTree": release.descriptor.sourceTree,
            "artifact": artifact_relative.as_posix(),
            "artifactSha256": artifact_sha,
            "runtime": runtime_relative.as_posix(),
            "runtimeDigest": runtime_digest,
            "binding": binding_relative.as_posix(),
            "bindingSha256": binding_sha,
            "dependencies": dependencies,
            "enabled": False,
            "mode": "shadow",
        }
        previous = capabilities.get(release.manifest.name)
        if previous is not None and previous != locked and not upgrade:
            raise ValueError("capability lock conflict; use --upgrade")
        capabilities[release.manifest.name] = locked
        project_path = root / "project.yaml"
        if not project_path.exists():
            _atomic_replace(
                project_path,
                _yaml_bytes(
                    {
                        "apiVersion": "futurizta.project/v1",
                        "name": target.name,
                        "runtime": {"python": project_python},
                    }
                ),
            )
        _atomic_replace(
            lock_path,
            _yaml_bytes({"apiVersion": "futurizta.lock/v1", "capabilities": capabilities}),
        )
        fcntl.flock(install_lock.fileno(), fcntl.LOCK_UN)
    return plan


def plan_json(plan: InstallPlan) -> str:
    return json.dumps(plan.to_dict(), indent=2, sort_keys=True)
