from __future__ import annotations

from pathlib import Path
from typing import Annotated, Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator
from yaml.resolver import BaseResolver


class UniqueKeyLoader(yaml.SafeLoader):
    pass


def _construct_unique_mapping(
    loader: UniqueKeyLoader,
    node: yaml.MappingNode,
    deep: bool = False,
) -> dict[Any, Any]:
    mapping: dict[Any, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        try:
            if key in mapping:
                raise ValueError(f"duplicate YAML mapping key: {key}")
            mapping[key] = loader.construct_object(value_node, deep=deep)
        except TypeError as exc:
            raise ValueError("YAML mapping keys must be scalar and hashable") from exc
    return mapping


UniqueKeyLoader.add_constructor(BaseResolver.DEFAULT_MAPPING_TAG, _construct_unique_mapping)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Source(StrictModel):
    repository: str
    commit: str | None = None
    digest: str | None = None

    @model_validator(mode="after")
    def immutable_reference(self) -> "Source":
        if not self.commit and not self.digest:
            raise ValueError("source requires commit or digest")
        return self


class Compatibility(StrictModel):
    runtimes: dict[str, str] = Field(default_factory=dict)
    adapters: list[str] = Field(default_factory=list)
    targetContracts: list[str] = Field(default_factory=list)


class ContractRef(StrictModel):
    name: str
    schema_: str = Field(alias="schema")
    asset: str | None = None


class ConfigurationItem(StrictModel):
    type: Literal["string", "integer", "number", "boolean", "object", "secretRef"]
    required: bool = False
    default: Any = None

    @model_validator(mode="after")
    def default_matches_type(self) -> "ConfigurationItem":
        if self.default is None:
            return self
        if self.type == "secretRef":
            raise ValueError("secretRef configuration cannot declare a default")
        if self.type == "integer":
            if isinstance(self.default, int) and not isinstance(self.default, bool):
                return self
            if isinstance(self.default, float) and self.default.is_integer():
                object.__setattr__(self, "default", int(self.default))
                return self
            raise ValueError("default must match type=integer")
        expected = {
            "string": str,
            "number": (int, float),
            "boolean": bool,
            "object": dict,
        }[self.type]
        if isinstance(self.default, bool) and self.type == "number":
            raise ValueError("default must match type=number")
        if not isinstance(self.default, expected):
            raise ValueError(f"default must match type={self.type}")
        return self


ConfigurationKey = Annotated[str, Field(pattern=r"^[a-z][a-z0-9_]*$")]


class Permissions(StrictModel):
    network: list[str] = Field(default_factory=list)
    data: list[str] = Field(default_factory=list)
    externalActions: list[str] = Field(default_factory=list)
    approval: Literal["none", "required", "per-run"] = "none"

    @model_validator(mode="after")
    def external_actions_require_approval(self) -> "Permissions":
        if self.externalActions and self.approval == "none":
            raise ValueError("externalActions require approval=required or per-run")
        return self


class Automation(StrictModel):
    entrypoint: str
    deploymentName: str
    parametersSchema: str | None = None
    defaultSchedule: str | None = None
    workPoolClass: str | None = None
    concurrencyLimit: int | None = Field(default=None, ge=1)
    eventTriggers: list[dict[str, Any]] = Field(default_factory=list)


class Skill(StrictModel):
    entrypoint: str = "SKILL.md"
    agents: list[str] = Field(default_factory=list)
    allowedTools: list[str] = Field(default_factory=list)
    triggers: list[str] = Field(default_factory=list)


class Module(StrictModel):
    package: str
    routeNamespace: str | None = None
    migrations: list[str] = Field(default_factory=list)


class Verification(StrictModel):
    commands: list[str] = Field(min_length=1)
    healthCheck: dict[str, Any] | None = None


class CapabilityManifest(StrictModel):
    apiVersion: Literal["futurizta.capabilities/v1"]
    kind: Literal["skill", "module", "automation", "composite"]
    name: str = Field(pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    displayName: str
    version: str = Field(pattern=r"^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$")
    description: str
    owners: list[str] = Field(min_length=1)
    source: Source
    license: str
    compatibility: Compatibility = Field(default_factory=Compatibility)
    inputs: list[ContractRef] = Field(default_factory=list)
    outputs: list[ContractRef] = Field(default_factory=list)
    configuration: dict[ConfigurationKey, ConfigurationItem] = Field(default_factory=dict)
    permissions: Permissions = Field(default_factory=Permissions)
    automation: Automation | None = None
    skill: Skill | None = None
    module: Module | None = None
    components: list[str] = Field(default_factory=list)
    verification: Verification

    @model_validator(mode="after")
    def kind_payload_matches(self) -> "CapabilityManifest":
        payloads = {
            "automation": self.automation,
            "skill": self.skill,
            "module": self.module,
            "composite": self.components or None,
        }
        if not payloads[self.kind]:
            raise ValueError(f"kind={self.kind} requires its matching configuration")
        unexpected = sorted(
            name for name, payload in payloads.items() if name != self.kind and payload
        )
        if unexpected:
            raise ValueError(
                f"kind={self.kind} cannot include configuration for: {', '.join(unexpected)}"
            )
        return self


def manifest_path(path: str | Path) -> Path:
    candidate = Path(path)
    return candidate / "capability.yaml" if candidate.is_dir() else candidate


def load_manifest(path: str | Path) -> CapabilityManifest:
    target = manifest_path(path)
    with target.open(encoding="utf-8") as handle:
        raw = yaml.load(handle, Loader=UniqueKeyLoader)
    if not isinstance(raw, dict):
        raise ValueError(f"{target}: manifest root must be an object")
    manifest = CapabilityManifest.model_validate(raw)
    _validate_local_references(target, manifest)
    return manifest


def _validate_local_references(target: Path, manifest: CapabilityManifest) -> None:
    candidates = (target.parent, *target.parents)
    declared = Path(manifest.source.repository).expanduser()
    if not declared.is_absolute():
        declared = target.parent / declared
    declared = declared.resolve()
    repository = (
        declared
        if declared.is_dir()
        else next(
            (parent for parent in candidates if (parent / "pyproject.toml").is_file()),
            next(
                (parent for parent in candidates if (parent / "schemas").is_dir()),
                target.parent,
            ),
        ).resolve()
    )
    for contract in (*manifest.inputs, *manifest.outputs):
        reference = (repository / contract.schema_).resolve()
        if not reference.is_relative_to(repository):
            raise ValueError(f"schema path escapes repository: {contract.schema_}")
        if not reference.is_file():
            raise ValueError(f"missing contract schema: {contract.schema_}")


def validate_manifest(path: str | Path) -> tuple[CapabilityManifest | None, list[str]]:
    try:
        return load_manifest(path), []
    except (OSError, ValueError, ValidationError, yaml.YAMLError) as exc:
        return None, [str(exc)]
