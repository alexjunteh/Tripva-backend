from __future__ import annotations

import ast
import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from urllib.parse import urlsplit


ENV_PATTERN = re.compile(r"(?:os\.environ\.get|os\.getenv)\(\s*['\"]([A-Z][A-Z0-9_]*)['\"]")
ABSOLUTE_PATH_PATTERN = re.compile(r"['\"](/(?:home|tmp|opt|var|etc)/[^'\"]+)['\"]")
TABLE_PATTERN = re.compile(
    r"\b(?:FROM|JOIN|INTO|UPDATE|TABLE)\s+(?:\[?dbo\]?\.)?\[?([A-Za-z_][A-Za-z0-9_]*)\]?",
    re.IGNORECASE,
)
SQL_STATEMENT_PATTERN = re.compile(
    r"\b(?:SELECT\b[\s\S]*?\bFROM|INSERT\s+INTO|UPDATE\b[\s\S]*?\bSET|"
    r"CREATE\s+TABLE|ALTER\s+TABLE|DELETE\s+FROM|MERGE\s+INTO)\b",
    re.IGNORECASE,
)
URL_PATTERN = re.compile(r"https?://[^\s'\"]+")
SECRET_ASSIGNMENT_PATTERN = re.compile(
    r"^(?P<name>(?:[A-Z][A-Z0-9_]*_)?(?:PASSWORD|TOKEN|SECRET|API_KEY)(?:_[A-Z0-9_]+)?)\s*=\s*['\"](?P<value>[^'\"]+)['\"]",
    re.MULTILINE,
)


@dataclass
class FileInventory:
    path: str
    sha256: str
    lines: int
    imports: list[str] = field(default_factory=list)
    environment: list[str] = field(default_factory=list)
    absolutePaths: list[str] = field(default_factory=list)
    sqlTables: list[str] = field(default_factory=list)
    urls: list[str] = field(default_factory=list)
    secretLikeDefaults: list[str] = field(default_factory=list)


@dataclass
class RepositoryInventory:
    repository: str
    includes: list[str]
    files: list[FileInventory]
    summary: dict[str, int]

    def to_dict(self) -> dict:
        return {
            "repository": self.repository,
            "includes": self.includes,
            "files": [asdict(item) for item in self.files],
            "summary": self.summary,
        }


def _imports(text: str) -> list[str]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.add(node.module)
    return sorted(names)


def _sql_tables(text: str) -> list[str]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []

    tables: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Constant) or not isinstance(node.value, str):
            continue
        if SQL_STATEMENT_PATTERN.search(node.value):
            tables.update(TABLE_PATTERN.findall(node.value))
    return sorted(tables)


def _url_origins(text: str) -> list[str]:
    origins: set[str] = set()
    for raw in URL_PATTERN.findall(text):
        parsed = urlsplit(raw.rstrip("`.,);]"))
        if parsed.scheme in {"http", "https"} and parsed.hostname:
            port = f":{parsed.port}" if parsed.port else ""
            origins.add(f"{parsed.scheme}://{parsed.hostname}{port}")
    return sorted(origins)


def _relative_files(repo: Path, includes: list[str]) -> list[Path]:
    files: set[Path] = set()
    for include in includes:
        target = (repo / include).resolve()
        if not target.is_relative_to(repo.resolve()):
            raise ValueError(f"include escapes repository: {include}")
        if not target.exists():
            raise ValueError(f"include not found: {include}")
        if target.is_file() and target.suffix == ".py":
            files.add(target)
        elif target.is_dir():
            for path in target.rglob("*.py"):
                resolved = path.resolve()
                if not resolved.is_relative_to(repo.resolve()):
                    raise ValueError(f"included symlink escapes repository: {path}")
                if resolved.is_file():
                    files.add(resolved)
        else:
            raise ValueError(f"include is not a Python file or directory: {include}")
    return sorted(files)


def scan_repository(repository: str | Path, includes: list[str]) -> RepositoryInventory:
    repo = Path(repository).resolve()
    if not repo.is_dir():
        raise ValueError(f"repository not found: {repo}")
    if not includes:
        raise ValueError("at least one --include path is required")

    inventory: list[FileInventory] = []
    for path in _relative_files(repo, includes):
        raw_bytes = path.read_bytes()
        text = raw_bytes.decode("utf-8", errors="replace")
        secret_names = sorted({match.group("name") for match in SECRET_ASSIGNMENT_PATTERN.finditer(text)})
        inventory.append(
            FileInventory(
                path=str(path.relative_to(repo)),
                sha256=hashlib.sha256(raw_bytes).hexdigest(),
                lines=text.count("\n") + 1,
                imports=_imports(text),
                environment=sorted(set(ENV_PATTERN.findall(text))),
                absolutePaths=sorted(set(ABSOLUTE_PATH_PATTERN.findall(text))),
                sqlTables=_sql_tables(text),
                urls=_url_origins(text),
                secretLikeDefaults=secret_names,
            )
        )

    if not inventory:
        raise ValueError("inventory scope contains no Python files")

    summary = {
        "fileCount": len(inventory),
        "lineCount": sum(item.lines for item in inventory),
        "environmentVariableCount": len({v for item in inventory for v in item.environment}),
        "absolutePathCount": len({v for item in inventory for v in item.absolutePaths}),
        "sqlTableCount": len({v for item in inventory for v in item.sqlTables}),
        "urlCount": len({v for item in inventory for v in item.urls}),
        "secretLikeDefaultCount": len({v for item in inventory for v in item.secretLikeDefaults}),
    }
    return RepositoryInventory(str(repo), includes, inventory, summary)


def write_inventory(inventory: RepositoryInventory, output: str | Path) -> None:
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(inventory.to_dict(), indent=2) + "\n", encoding="utf-8")
