from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CreativeBrief(StrictModel):
    id: str = Field(min_length=1)
    idempotency_key: str = Field(min_length=1)
    subject_id: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    channel: str = Field(min_length=1)
    requested_by: str = Field(min_length=1)
    format: Literal["image"] = "image"
    angle: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ReferenceAsset(StrictModel):
    id: str
    uri: str
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    role: str = "subject-reference"


class ReferencePack(StrictModel):
    id: str
    subject_id: str
    version: str
    locked: bool
    assets: tuple[ReferenceAsset, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def matches_subject(self) -> "ReferencePack":
        if not self.locked:
            raise ValueError("reference pack must be locked")
        return self


class GenerationRequest(StrictModel):
    idempotency_key: str = Field(min_length=1)
    brief: CreativeBrief
    references: ReferencePack
    attempt: int = Field(ge=1)
    retry_guidance: tuple[str, ...] = ()


class GeneratedArtifact(StrictModel):
    id: str = Field(min_length=1)
    uri: str = Field(min_length=1)
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    provider: str = Field(min_length=1)
    provider_run_id: str = Field(min_length=1)
    content_type: str = "image/png"
    cost_usd: float = Field(ge=0)
    metadata: dict[str, Any] = Field(default_factory=dict)


class BudgetReservation(StrictModel):
    id: str = Field(min_length=1)
    allowed: bool
    estimated_cost_usd: float = Field(ge=0)
    reason: str | None = None

    @model_validator(mode="after")
    def denial_has_reason(self) -> "BudgetReservation":
        if not self.allowed and not self.reason:
            raise ValueError("denied budget reservation requires a reason")
        return self


class EvaluationVerdict(StrEnum):
    PASS = "pass"
    REJECT = "reject"
    NEEDS_REVIEW = "needs_review"
    ERROR = "error"


class EvaluationResult(StrictModel):
    verdict: EvaluationVerdict
    evaluator: str = Field(min_length=1)
    evaluator_version: str = Field(min_length=1)
    confidence: float = Field(ge=0, le=1)
    scores: dict[str, float] = Field(default_factory=dict)
    hard_failures: tuple[str, ...] = ()
    retry_guidance: tuple[str, ...] = ()
    evidence: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def pass_has_no_hard_failures(self) -> "EvaluationResult":
        if self.verdict == EvaluationVerdict.PASS and self.hard_failures:
            raise ValueError("pass verdict cannot contain hard failures")
        return self


class AssetQaStatus(StrEnum):
    APPROVED = "approved"
    REJECTED = "rejected"
    PENDING_REVIEW = "pending_review"


class AssetRecord(StrictModel):
    idempotency_key: str = Field(min_length=1)
    brief_id: str = Field(min_length=1)
    brief_idempotency_key: str = Field(min_length=1)
    subject_id: str = Field(min_length=1)
    artifact: GeneratedArtifact
    reference_pack_id: str = Field(min_length=1)
    reference_pack_version: str = Field(min_length=1)
    evaluation: EvaluationResult
    qa_status: AssetQaStatus
    generation_attempt: int = Field(ge=1)

    @model_validator(mode="after")
    def qa_matches_evaluation(self) -> "AssetRecord":
        expected = {
            EvaluationVerdict.PASS: AssetQaStatus.APPROVED,
            EvaluationVerdict.REJECT: AssetQaStatus.REJECTED,
            EvaluationVerdict.NEEDS_REVIEW: AssetQaStatus.PENDING_REVIEW,
            EvaluationVerdict.ERROR: AssetQaStatus.PENDING_REVIEW,
        }[self.evaluation.verdict]
        if self.qa_status != expected:
            raise ValueError("qa_status must match evaluation verdict")
        return self


class ClaimState(StrEnum):
    ACQUIRED = "acquired"
    APPROVED = "approved"
    COMPLETED = "completed"
    IN_PROGRESS = "in_progress"


class AssetClaim(StrictModel):
    state: ClaimState
    lease_id: str | None = None
    asset: AssetRecord | None = None

    @model_validator(mode="after")
    def state_payload_matches(self) -> "AssetClaim":
        if self.state == ClaimState.ACQUIRED and not self.lease_id:
            raise ValueError("acquired claim requires lease_id")
        terminal_states = {ClaimState.APPROVED, ClaimState.COMPLETED}
        if self.state in terminal_states and self.asset is None:
            raise ValueError("terminal claim requires asset")
        if self.state not in terminal_states and self.asset is not None:
            raise ValueError("only terminal claim may include asset")
        return self


class PipelineStatus(StrEnum):
    APPROVED = "approved"
    REJECTED = "rejected"
    NEEDS_REVIEW = "needs_review"
    BLOCKED = "blocked"
    FAILED = "failed"


class PipelineResult(StrictModel):
    status: PipelineStatus
    brief_id: str
    attempts: int
    asset: AssetRecord | None = None
    reason: str | None = None
    generated_artifact_ids: tuple[str, ...] = ()
