from __future__ import annotations

from dataclasses import dataclass

from .contracts import (
    AssetQaStatus,
    AssetRecord,
    ClaimState,
    CreativeBrief,
    EvaluationResult,
    EvaluationVerdict,
    GenerationRequest,
    PipelineResult,
    PipelineStatus,
)
from .ports import AssetRegistry, BudgetGate, ImageGenerator, QualityEvaluator, ReferencePolicy


@dataclass(frozen=True)
class ImagePipeline:
    references: ReferencePolicy
    budget: BudgetGate
    generator: ImageGenerator
    evaluator: QualityEvaluator
    registry: AssetRegistry
    max_attempts: int = 3
    claim_lease_seconds: int = 900

    def __post_init__(self) -> None:
        if not 1 <= self.max_attempts <= 3:
            raise ValueError("max_attempts must be between 1 and 3")
        if not 60 <= self.claim_lease_seconds <= 3600:
            raise ValueError("claim_lease_seconds must be between 60 and 3600")

    def run(self, brief: CreativeBrief) -> PipelineResult:
        try:
            claim = self.registry.claim(brief, self.claim_lease_seconds)
        except Exception:
            return _failed(brief, "registry_claim_failed")

        if claim.state in {ClaimState.APPROVED, ClaimState.COMPLETED}:
            existing = claim.asset
            if existing is None or not _matches_brief(existing, brief):
                return _failed(brief, "registry_claim_conflict")
            status = {
                AssetQaStatus.APPROVED: PipelineStatus.APPROVED,
                AssetQaStatus.REJECTED: PipelineStatus.REJECTED,
                AssetQaStatus.PENDING_REVIEW: PipelineStatus.NEEDS_REVIEW,
            }[existing.qa_status]
            return PipelineResult(
                status=status,
                brief_id=brief.id,
                attempts=0,
                asset=existing,
                reason="idempotent_replay",
                generated_artifact_ids=(existing.artifact.id,),
            )
        if claim.state == ClaimState.IN_PROGRESS:
            return PipelineResult(
                status=PipelineStatus.BLOCKED,
                brief_id=brief.id,
                attempts=0,
                reason="idempotent_request_in_progress",
            )

        lease_id = claim.lease_id
        if claim.state != ClaimState.ACQUIRED or lease_id is None:
            return _failed(brief, "invalid_registry_claim")

        try:
            result = self._run_claimed(brief, lease_id)
        except Exception:
            result = _failed(brief, "pipeline_internal_error")

        retain_claim_reasons = {"budget_reconcile_failed", "duplicate_artifact_id"}
        if result.status != PipelineStatus.APPROVED and result.reason not in retain_claim_reasons:
            try:
                self.registry.release(lease_id)
            except Exception:
                return _failed(
                    brief,
                    "registry_release_failed",
                    attempts=result.attempts,
                    generated_artifact_ids=result.generated_artifact_ids,
                )
        return result

    def _run_claimed(self, brief: CreativeBrief, lease_id: str) -> PipelineResult:

        try:
            reference_pack = self.references.resolve(brief)
            if reference_pack.subject_id != brief.subject_id:
                return PipelineResult(
                    status=PipelineStatus.REJECTED,
                    brief_id=brief.id,
                    attempts=0,
                    reason="reference_subject_mismatch",
                )
        except Exception:
            return PipelineResult(
                status=PipelineStatus.REJECTED,
                brief_id=brief.id,
                attempts=0,
                reason="reference_gate_failed",
            )

        generated_ids: list[str] = []
        retry_guidance: tuple[str, ...] = ()
        last_asset: AssetRecord | None = None

        for attempt in range(1, self.max_attempts + 1):
            try:
                reservation = self.budget.reserve(brief, attempt)
            except Exception:
                return _failed(
                    brief,
                    "budget_gate_failed",
                    attempts=attempt - 1,
                    generated_artifact_ids=tuple(generated_ids),
                )
            if not reservation.allowed:
                return PipelineResult(
                    status=PipelineStatus.BLOCKED,
                    brief_id=brief.id,
                    attempts=attempt - 1,
                    reason="budget_denied",
                    generated_artifact_ids=tuple(generated_ids),
                )

            request = GenerationRequest(
                idempotency_key=f"{brief.idempotency_key}:attempt:{attempt}",
                brief=brief,
                references=reference_pack,
                attempt=attempt,
                retry_guidance=retry_guidance,
            )
            try:
                artifact = self.generator.generate(request)
            except Exception:
                try:
                    self.budget.release(reservation.id)
                except Exception:
                    return PipelineResult(
                        status=PipelineStatus.FAILED,
                        brief_id=brief.id,
                        attempts=attempt,
                        reason="budget_release_failed",
                        generated_artifact_ids=tuple(generated_ids),
                    )
                return PipelineResult(
                    status=PipelineStatus.FAILED,
                    brief_id=brief.id,
                    attempts=attempt,
                    reason="generation_failed",
                    generated_artifact_ids=tuple(generated_ids),
                )
            try:
                self.budget.reconcile(reservation.id, artifact)
            except Exception:
                return PipelineResult(
                    status=PipelineStatus.BLOCKED,
                    brief_id=brief.id,
                    attempts=attempt,
                    reason="budget_reconcile_failed",
                    generated_artifact_ids=tuple(generated_ids),
                )
            if artifact.id in generated_ids:
                return PipelineResult(
                    status=PipelineStatus.BLOCKED,
                    brief_id=brief.id,
                    attempts=attempt,
                    reason="duplicate_artifact_id",
                    generated_artifact_ids=tuple(generated_ids),
                )
            generated_ids.append(artifact.id)

            try:
                evaluation = self.evaluator.evaluate(brief, reference_pack, artifact)
            except Exception as exc:
                evaluation = EvaluationResult(
                    verdict=EvaluationVerdict.ERROR,
                    evaluator=type(self.evaluator).__name__,
                    evaluator_version="unknown",
                    confidence=0,
                    hard_failures=("evaluator_unavailable",),
                    evidence={"error_type": type(exc).__name__},
                )

            qa_status = _qa_status(evaluation.verdict)
            asset = AssetRecord(
                idempotency_key=(
                    f"{brief.idempotency_key}:{artifact.id}:"
                    f"{evaluation.evaluator}:{evaluation.evaluator_version}"
                ),
                brief_id=brief.id,
                brief_idempotency_key=brief.idempotency_key,
                subject_id=brief.subject_id,
                artifact=artifact,
                reference_pack_id=reference_pack.id,
                reference_pack_version=reference_pack.version,
                evaluation=evaluation,
                qa_status=qa_status,
                generation_attempt=attempt,
            )
            try:
                last_asset = self.registry.register(lease_id, asset)
            except Exception:
                return _failed(
                    brief,
                    "registry_register_failed",
                    attempts=attempt,
                    generated_artifact_ids=tuple(generated_ids),
                )
            if last_asset != asset:
                return _failed(
                    brief,
                    "registry_record_conflict",
                    attempts=attempt,
                    generated_artifact_ids=tuple(generated_ids),
                )

            if last_asset.qa_status == AssetQaStatus.APPROVED:
                return PipelineResult(
                    status=PipelineStatus.APPROVED,
                    brief_id=brief.id,
                    attempts=attempt,
                    asset=last_asset,
                    generated_artifact_ids=tuple(generated_ids),
                )
            if evaluation.verdict in (EvaluationVerdict.NEEDS_REVIEW, EvaluationVerdict.ERROR):
                return PipelineResult(
                    status=PipelineStatus.NEEDS_REVIEW,
                    brief_id=brief.id,
                    attempts=attempt,
                    asset=last_asset,
                    reason=evaluation.verdict.value,
                    generated_artifact_ids=tuple(generated_ids),
                )

            retry_guidance = evaluation.retry_guidance or evaluation.hard_failures

        return PipelineResult(
            status=PipelineStatus.REJECTED,
            brief_id=brief.id,
            attempts=self.max_attempts,
            asset=last_asset,
            reason="evaluation_rejected_after_max_attempts",
            generated_artifact_ids=tuple(generated_ids),
        )


def _qa_status(verdict: EvaluationVerdict) -> AssetQaStatus:
    if verdict == EvaluationVerdict.PASS:
        return AssetQaStatus.APPROVED
    if verdict == EvaluationVerdict.REJECT:
        return AssetQaStatus.REJECTED
    return AssetQaStatus.PENDING_REVIEW


def _matches_brief(asset: AssetRecord, brief: CreativeBrief) -> bool:
    return (
        asset.brief_id == brief.id
        and asset.brief_idempotency_key == brief.idempotency_key
        and asset.subject_id == brief.subject_id
    )


def _failed(
    brief: CreativeBrief,
    reason: str,
    *,
    attempts: int = 0,
    generated_artifact_ids: tuple[str, ...] = (),
) -> PipelineResult:
    return PipelineResult(
        status=PipelineStatus.FAILED,
        brief_id=brief.id,
        attempts=attempts,
        reason=reason,
        generated_artifact_ids=generated_artifact_ids,
    )
