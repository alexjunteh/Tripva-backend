from __future__ import annotations

import hashlib
import sqlite3
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .contracts import (
    AssetClaim,
    AssetQaStatus,
    AssetRecord,
    BudgetReservation,
    ClaimState,
    CreativeBrief,
    GeneratedArtifact,
)


@dataclass
class AtomicZeroBudget:
    database: Path
    estimated_cost_usd: float = 0
    clock: Callable[[], float] = time.time

    def __post_init__(self) -> None:
        self.database = self.database.resolve()
        self.database.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS capability_budget_reservations (
                    id TEXT PRIMARY KEY,
                    request_key TEXT NOT NULL UNIQUE,
                    estimated_cost_usd REAL NOT NULL,
                    actual_cost_usd REAL,
                    status TEXT NOT NULL,
                    created_at REAL NOT NULL
                )"""
            )

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.database, timeout=5)

    def reserve(self, brief: CreativeBrief, attempt: int) -> BudgetReservation:
        request_key = f"{brief.idempotency_key}:attempt:{attempt}"
        reservation_id = hashlib.sha256(request_key.encode()).hexdigest()
        allowed = self.estimated_cost_usd == 0
        reason = None if allowed else "shadow_zero_budget"
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT estimated_cost_usd, status FROM capability_budget_reservations WHERE request_key = ?",
                (request_key,),
            ).fetchone()
            if existing is None:
                connection.execute(
                    "INSERT INTO capability_budget_reservations VALUES (?, ?, ?, NULL, ?, ?)",
                    (
                        reservation_id,
                        request_key,
                        self.estimated_cost_usd,
                        "reserved" if allowed else "denied",
                        self.clock(),
                    ),
                )
            elif float(existing[0]) != self.estimated_cost_usd:
                raise ValueError("budget reservation idempotency conflict")
            else:
                allowed = False
                reason = f"budget_reservation_{existing[1]}"
            connection.commit()
        return BudgetReservation(
            id=reservation_id,
            allowed=allowed,
            estimated_cost_usd=self.estimated_cost_usd,
            reason=reason,
        )

    def reconcile(self, reservation_id: str, artifact: GeneratedArtifact) -> None:
        if artifact.cost_usd != 0:
            raise ValueError("shadow artifact cost must remain zero")
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT status, actual_cost_usd FROM capability_budget_reservations WHERE id = ?",
                (reservation_id,),
            ).fetchone()
            if row is None or row[0] not in {"reserved", "reconciled"}:
                raise ValueError("budget reservation is not reconcilable")
            if row[0] == "reconciled" and float(row[1]) != artifact.cost_usd:
                raise ValueError("budget reconciliation conflict")
            connection.execute(
                "UPDATE capability_budget_reservations SET actual_cost_usd = ?, status = 'reconciled' WHERE id = ?",
                (artifact.cost_usd, reservation_id),
            )
            connection.commit()

    def release(self, reservation_id: str) -> None:
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "UPDATE capability_budget_reservations SET status = 'released' WHERE id = ? AND status = 'reserved'",
                (reservation_id,),
            )
            connection.commit()


@dataclass
class SqliteAssetRegistry:
    database: Path
    clock: Callable[[], float] = time.time

    def __post_init__(self) -> None:
        self.database = self.database.resolve()
        self.database.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.executescript(
                """CREATE TABLE IF NOT EXISTS capability_asset_claims (
                    brief_key TEXT PRIMARY KEY,
                    lease_id TEXT NOT NULL UNIQUE,
                    brief_id TEXT NOT NULL,
                    subject_id TEXT NOT NULL,
                    expires_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS capability_assets (
                    asset_key TEXT PRIMARY KEY,
                    brief_key TEXT NOT NULL,
                    brief_id TEXT NOT NULL,
                    subject_id TEXT NOT NULL,
                    qa_status TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS capability_one_approved_asset
                    ON capability_assets(brief_key) WHERE qa_status = 'approved';"""
            )

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.database, timeout=5)

    def claim(self, brief: CreativeBrief, lease_seconds: int) -> AssetClaim:
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            terminal = connection.execute(
                "SELECT record_json, qa_status FROM capability_assets WHERE brief_key = ? ORDER BY rowid DESC LIMIT 1",
                (brief.idempotency_key,),
            ).fetchone()
            if terminal is not None:
                connection.commit()
                asset = AssetRecord.model_validate_json(terminal[0])
                return AssetClaim(
                    state=(
                        ClaimState.APPROVED
                        if terminal[1] == AssetQaStatus.APPROVED.value
                        else ClaimState.COMPLETED
                    ),
                    asset=asset,
                )
            now = self.clock()
            existing = connection.execute(
                "SELECT lease_id, expires_at FROM capability_asset_claims WHERE brief_key = ?",
                (brief.idempotency_key,),
            ).fetchone()
            if existing is not None and float(existing[1]) > now:
                connection.commit()
                return AssetClaim(state=ClaimState.IN_PROGRESS)
            lease_id = uuid.uuid4().hex
            connection.execute(
                """INSERT INTO capability_asset_claims
                   (brief_key, lease_id, brief_id, subject_id, expires_at)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(brief_key) DO UPDATE SET
                     lease_id=excluded.lease_id,
                     brief_id=excluded.brief_id,
                     subject_id=excluded.subject_id,
                     expires_at=excluded.expires_at""",
                (brief.idempotency_key, lease_id, brief.id, brief.subject_id, now + lease_seconds),
            )
            connection.commit()
            return AssetClaim(state=ClaimState.ACQUIRED, lease_id=lease_id)

    def register(self, lease_id: str, asset: AssetRecord) -> AssetRecord:
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            claim = connection.execute(
                "SELECT brief_key, brief_id, subject_id, expires_at FROM capability_asset_claims WHERE lease_id = ?",
                (lease_id,),
            ).fetchone()
            if claim is None or float(claim[3]) <= self.clock():
                raise ValueError("asset lease is missing or expired")
            if claim[:3] != (
                asset.brief_idempotency_key,
                asset.brief_id,
                asset.subject_id,
            ):
                raise ValueError("asset lease identity mismatch")
            existing = connection.execute(
                "SELECT record_json FROM capability_assets WHERE asset_key = ?",
                (asset.idempotency_key,),
            ).fetchone()
            if existing is not None:
                connection.commit()
                return AssetRecord.model_validate_json(existing[0])
            connection.execute(
                "INSERT INTO capability_assets VALUES (?, ?, ?, ?, ?, ?)",
                (
                    asset.idempotency_key,
                    asset.brief_idempotency_key,
                    asset.brief_id,
                    asset.subject_id,
                    asset.qa_status.value,
                    asset.model_dump_json(),
                ),
            )
            if asset.qa_status == AssetQaStatus.APPROVED:
                connection.execute(
                    "DELETE FROM capability_asset_claims WHERE lease_id = ?",
                    (lease_id,),
                )
            connection.commit()
            return asset

    def release(self, lease_id: str) -> None:
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "DELETE FROM capability_asset_claims WHERE lease_id = ?",
                (lease_id,),
            )
            connection.commit()
