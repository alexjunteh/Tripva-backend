from __future__ import annotations

from typing import Protocol

from .contracts import (
    AssetClaim,
    AssetRecord,
    BudgetReservation,
    CreativeBrief,
    EvaluationResult,
    GeneratedArtifact,
    GenerationRequest,
    ReferencePack,
)


class ReferencePolicy(Protocol):
    def resolve(self, brief: CreativeBrief) -> ReferencePack: ...


class BudgetGate(Protocol):
    def reserve(self, brief: CreativeBrief, attempt: int) -> BudgetReservation: ...

    def reconcile(self, reservation_id: str, artifact: GeneratedArtifact) -> None: ...

    def release(self, reservation_id: str) -> None: ...


class ImageGenerator(Protocol):
    def generate(self, request: GenerationRequest) -> GeneratedArtifact: ...


class QualityEvaluator(Protocol):
    def evaluate(
        self,
        brief: CreativeBrief,
        references: ReferencePack,
        artifact: GeneratedArtifact,
    ) -> EvaluationResult: ...


class AssetRegistry(Protocol):
    def claim(self, brief: CreativeBrief, lease_seconds: int) -> AssetClaim: ...

    def register(self, lease_id: str, asset: AssetRecord) -> AssetRecord: ...

    def release(self, lease_id: str) -> None: ...
